import { useState } from "react";
import Section from "./Section.jsx";
import { profile } from "../data.js";

const empty = { name: "", email: "", subject: "", message: "" };

function validate(v) {
  const e = {};
  if (v.name.trim().length < 2) e.name = "Enter your name (at least 2 characters).";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) e.email = "Enter a valid email address.";
  if (v.subject.trim().length < 3) e.subject = "Enter a subject (at least 3 characters).";
  if (v.message.trim().length < 10) e.message = "Write a message of at least 10 characters.";
  return e;
}

export default function Contact() {
  const [values, setValues] = useState(empty);
  const [errors, setErrors] = useState({});
  const [done, setDone] = useState(false);

  const change = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
    setDone(false);
  };

  // No backend is configured, so a valid form opens the visitor's own email app.
  const submit = (e) => {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) return;
    const body = `${values.message}\n\nFrom: ${values.name} (${values.email})`;
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent(values.subject)}&body=${encodeURIComponent(body)}`;
    setDone(true);
  };

  const field = (name, label, props = {}) => (
    <div className="field">
      <label htmlFor={name}>{label}</label>
      {props.area ? (
        <textarea id={name} name={name} rows="5" value={values[name]} onChange={change}
          aria-invalid={!!errors[name]} aria-describedby={`${name}-err`} />
      ) : (
        <input id={name} name={name} type={props.type || "text"} value={values[name]} onChange={change}
          aria-invalid={!!errors[name]} aria-describedby={`${name}-err`} />
      )}
      <span id={`${name}-err`} className="err" role="alert">{errors[name]}</span>
    </div>
  );

  const social = (label, url) =>
    url ? <a href={url} target="_blank" rel="noreferrer">{label}</a> : <span className="muted">{label}: link to be added</span>;

  return (
    <Section id="contact" title="Contact" tint>
      <div className="two">
        <div>
          <p className="body">I'm open to internships, entry-level roles and conversations about data analytics and software development.</p>
          <ul className="contact-list">
            <li><span>Email</span><a href={`mailto:${profile.email}`}>{profile.email}</a></li>
            <li><span>Phone</span><a href={`tel:${profile.phoneLink}`}>{profile.phone}</a></li>
            <li><span>Location</span>{profile.location}</li>
            <li><span>LinkedIn</span>{social("LinkedIn", profile.linkedin)}</li>
            <li><span>GitHub</span>{social("GitHub", profile.github)}</li>
          </ul>
        </div>
        <form className="card form" onSubmit={submit} noValidate>
          {field("name", "Name")}
          {field("email", "Email", { type: "email" })}
          {field("subject", "Subject")}
          {field("message", "Message", { area: true })}
          <button className="btn primary" type="submit">Open in my email app</button>
          {done && (
            <p className="note" role="status">
              Your email app should open with this message ready. It is only sent when you press Send there.
            </p>
          )}
        </form>
      </div>
    </Section>
  );
}
