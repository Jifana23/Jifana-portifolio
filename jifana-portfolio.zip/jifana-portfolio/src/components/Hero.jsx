import { profile } from "../data.js";

export default function Hero() {
  return (
    <section id="home" className="hero">
      <div className="wrap hero-grid">
        <div className="hero-text">
          <p className="hello">Hi, I'm {profile.name}</p>
          <h1>{profile.heading}</h1>
          <p className="lead">{profile.intro}</p>
          <div className="btns">
            <a className="btn primary" href="#projects">View my projects</a>
            <a className="btn ghost" href={profile.cv} download>Download CV</a>
          </div>
          <p className="where">{profile.location}</p>
        </div>
        <div className="photo-frame">
          <img src={profile.photo} alt={`Portrait of ${profile.name}`} width="520" height="668" fetchpriority="high" />
        </div>
      </div>
    </section>
  );
}
