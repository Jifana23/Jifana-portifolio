import { useState } from "react";
import { nav, profile } from "../data.js";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="nav">
      <div className="wrap nav-inner">
        <a href="#home" className="logo" onClick={() => setOpen(false)}>{profile.name}</a>
        <button
          className="menu-btn"
          aria-expanded={open}
          aria-controls="nav-links"
          onClick={() => setOpen(!open)}
        >
          {open ? "Close" : "Menu"}
        </button>
        <nav id="nav-links" className={open ? "links open" : "links"} aria-label="Main">
          {nav.map((n) => (
            <a key={n} href={`#${n.toLowerCase()}`} onClick={() => setOpen(false)}>{n}</a>
          ))}
        </nav>
      </div>
    </header>
  );
}
