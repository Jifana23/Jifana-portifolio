import Section from "./Section.jsx";
import { about, strengths, skills, experience, projects, education, certifications, languages } from "../data.js";

export function About() {
  return (
    <Section id="about" title="About me">
      <div className="two">
        <div>{about.map((p) => <p key={p} className="body">{p}</p>)}</div>
        <ul className="chips big">{strengths.map((s) => <li key={s}>{s}</li>)}</ul>
      </div>
    </Section>
  );
}

export function Skills() {
  return (
    <Section id="skills" title="Technical skills" tint>
      <div className="grid">
        {skills.map((s) => (
          <article className="card" key={s.group}>
            <h3>{s.group}</h3>
            <ul className="chips">{s.items.map((i) => <li key={i}>{i}</li>)}</ul>
          </article>
        ))}
      </div>
    </Section>
  );
}

export function Experience() {
  return (
    <Section id="experience" title="Internship experience">
      <article className="card exp">
        <h3>{experience.role}</h3>
        <p className="meta">{experience.company}</p>
        <ul className="list">{experience.points.map((p) => <li key={p}>{p}</li>)}</ul>
      </article>
    </Section>
  );
}

export function Projects() {
  return (
    <Section id="projects" title="Academic projects" tint>
      <div className="grid two-col">
        {projects.map((p) => (
          <article className="card project" key={p.title}>
            {p.image ? (
              <img className="shot" src={p.image} alt={`${p.title} screenshot`} loading="lazy" />
            ) : (
              <div className="shot placeholder">Project screenshot placeholder</div>
            )}
            <h3>{p.title}</h3>
            <p className="body">{p.description}</p>
            <p className="body"><strong>Why it matters: </strong>{p.impact}</p>
            {p.technologies.length > 0 ? (
              <ul className="chips">{p.technologies.map((t) => <li key={t}>{t}</li>)}</ul>
            ) : (
              <p className="muted">Technologies: to be added</p>
            )}
            {p.github ? (
              <a className="btn ghost small" href={p.github} target="_blank" rel="noreferrer">View on GitHub</a>
            ) : (
              <span className="muted">GitHub link: to be added</span>
            )}
          </article>
        ))}
      </div>
    </Section>
  );
}

export function Education() {
  return (
    <Section id="education" title="Education">
      <ol className="timeline">
        {education.map((e) => (
          <li key={e.title}>
            <h3>{e.title}{e.status && <span className="badge">{e.status}</span>}</h3>
            <p className="meta">{e.detail}</p>
          </li>
        ))}
      </ol>
      <div className="two extras">
        <div>
          <h3>Certification</h3>
          <ul className="chips">{certifications.map((c) => <li key={c}>{c}</li>)}</ul>
        </div>
        <div>
          <h3>Languages</h3>
          <ul className="chips">{languages.map((l) => <li key={l}>{l}</li>)}</ul>
        </div>
      </div>
    </Section>
  );
}
