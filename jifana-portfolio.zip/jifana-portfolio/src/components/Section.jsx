export default function Section({ id, title, children, tint }) {
  return (
    <section id={id} className={tint ? "section tint" : "section"}>
      <div className="wrap">
        <h2>{title}</h2>
        {children}
      </div>
    </section>
  );
}
